# Do NOT use the PR tracker as an issue tracker / chat
Currently I do not accept any issue reports of any kind whatsoever. I do not provide personal support. I do accept PRs that fix issues however. Do not use the PR tracker as a chat. I disabled the issue tracker for a reason. I will permanently ban any misuse of the PR tracker.

An excellent example of how obsessively preoccupied with self users can be, see this: https://github.com/uNetworking/uWebSockets/pull/741

# Do NOT post issues like these:

**There is no documentation whatsoever**  
While there is no written document or tutorial, most basic operations like accepting connections, getting messages, sending messages and closing a connection is either obvious or shown in the tests. There are **many** tests in this repo, you can look at them. Then we have some very detailed comments in the sources of most important function calls. If you want an overview you can easily run Doxygen on the repo and you will get almost more info than you will ever need. Stop complaining and do some digging on your own, or PR me some docs yourself. The issue tracker is not for posting questions after being stuck for less than 4 seconds.

I agree the multithreading takes some deeper understanding of the library to get right and there are many pitfalls (just like with any multithreading), but if you are doing multithreading you are either doing something wrong (like trying to circumvent the event-loop, this is super common among C++ers) or simply being too obsessed with premature optimization. Don't do threading if you're not fully committed to learning how the library works.

**Open the issue tracker so that I can post my compiler errors**  
The GitHub issue tracker was closed in November 2017 because of the endless, daily stream of duplicates and invalid issue reports of how the library "does not compile or work at all". As of September 25th, the library is known to compile on Windows, Linux and OS X. It is also known to be used by millions of end users all over the internet. **You** and **your** compiler errors are not at the center of the universe.

**I cannot compile or link the project \<insert compiler or linker error\>**  
Try a released version, master branch is where development happens. If you still have issues then you need to check your end very thoroughly before posting this issue. You are not the only one using µWS and it is probably not this broken.

**Fundamental feature X is broken**  
Again, check your end very thoroughly before posting such an issue. µWS is successfully used by many others.

**You are not using NAN, prebuild or \<insert overrated project X\>**  
I know, this is by design. Things like NAN would render this project a million times more bloated.

**Feature X is not 100% identical to feature X of `ws`**  
Things like EventEmitters differ in behavior between the two projects. Other differences are listed on the main README. This is by design.

**Compilation of µWebSockets has failed and there is no pre-compiled binary available for your system. Please install a supported C++11 compiler and reinstall the module 'uws'.**  
This error message is more accurate than you might think. Install a C++11 compiler or update your distribution. You can also dig in uws.js yourself for more information before posting this issue. New versions of Node.js will always mean a small delay until a new version of uws is published with pre-compiled binaries.

**I cannot get the project to work with \<insert something that is not even supported\>**  
The front-page clearly states what this project is and where it is supposed to work. Still people often ignore this information and simply assume that platform X should work, and when it doesn't then apparently this is my problem to solve.

* Electron is not Node.js, do not assume any Node.js project will work as an Electron project!
* Yarn is not NPM, do not assume any NPM project will work as a Yarn project!
* FreeBSD is not Linux, do not assume that FreeBSD will work just because of Linux is supported!
* Webpack & Babel & NEXE & whatever else black magic is not my problem! If you chose to break the library by transpiling it to Visual Basic Script and back to Fortran, then it is no longer the original project I released and tested. It is not my problem if you go and break it like this! Fix your problem!

**I don't understand the version scheme**
* 0.14.x = version of native µWS
* 8.14.x = version 8 of Node.js combined with version 0.14.x of µWS

**Did you mean this, or was this a mistake?**  
I often get people asking if I made a mistake by writing something on the front page, or linking to some video or doing something that is maybe a little weird. Yes, I know what I'm doing and I do not need people to point this out. Obviously spelling mistakes are mistakes but complete texts are not just "mistakenly put there". If you can read it, then I wanted you to read it.