#!/bin/bash
for ((COUNT = 1; COUNT <= 10000000000; COUNT++)); do
  echo test: message number: $COUNT
  sleep 1
done
