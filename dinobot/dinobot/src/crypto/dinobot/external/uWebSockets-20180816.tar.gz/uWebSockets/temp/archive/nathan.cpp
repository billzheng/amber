#include "uWS/uWS.h"
#include <iostream>

int main() {
    uWS::Hub h;

    h.onMessage([&h](uWS::WebSocket<uWS::SERVER> *ws, char *message, size_t length, uWS::OpCode opCode) {
        ws->send(message, length, opCode);
        std::cout << "nathan: output: " << message << std::endl;
    });

    h.getDefaultGroup<uWS::SERVER>().startAutoPing(1000);
    //h.listen("localhost", 3000);
    h.connect("wss://ws-feed.gdax.com", nullptr);
    h.run();

    return 1;
}
